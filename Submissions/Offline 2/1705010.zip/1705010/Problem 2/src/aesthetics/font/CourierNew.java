package aesthetics.font;

public class CourierNew implements Font{
    public String toString() {
        return "CourierNew";
    }
}
