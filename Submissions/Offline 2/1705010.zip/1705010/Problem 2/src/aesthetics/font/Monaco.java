package aesthetics.font;

public class Monaco implements Font{
    public String toString() {
        return "Monaco";
    }
}
