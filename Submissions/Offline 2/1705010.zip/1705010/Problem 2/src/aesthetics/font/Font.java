package aesthetics.font;

public interface Font {
    public String toString();
}
