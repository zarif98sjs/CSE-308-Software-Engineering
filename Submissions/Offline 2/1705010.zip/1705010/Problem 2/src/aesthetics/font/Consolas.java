package aesthetics.font;

public class Consolas implements Font{
    public String toString() {
        return "Consolas";
    }

}
