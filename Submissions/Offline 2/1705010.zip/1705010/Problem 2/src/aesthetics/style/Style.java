package aesthetics.style;

public interface Style {
    public String toString();
}
