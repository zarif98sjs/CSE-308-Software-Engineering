package aesthetics.style;

public class Normal implements Style{
    public String toString() {
        return "Normal";
    }
}
