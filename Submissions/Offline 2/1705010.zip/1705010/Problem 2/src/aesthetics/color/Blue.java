package aesthetics.color;

public class Blue implements Color{
    public String toString() {
        return "Blue";
    }
}
