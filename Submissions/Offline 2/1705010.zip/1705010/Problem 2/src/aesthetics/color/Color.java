package aesthetics.color;

public interface Color {
    public String toString();
}
