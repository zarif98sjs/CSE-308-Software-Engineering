package language.parser;

public interface Parser {
    public String toString();
}
