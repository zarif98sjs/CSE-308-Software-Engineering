package language.parser;

public class CParser implements Parser{
    public String toString() {
        return "CParser";
    }
}
