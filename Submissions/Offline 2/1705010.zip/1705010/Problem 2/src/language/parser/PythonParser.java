package language.parser;

public class PythonParser implements Parser{
    public String toString() {
        return "PythonParser";
    }
}
