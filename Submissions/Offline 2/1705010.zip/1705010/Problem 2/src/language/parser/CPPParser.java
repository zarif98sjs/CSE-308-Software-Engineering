package language.parser;

public class CPPParser implements Parser {
    public String toString() {
        return "CPPParser";
    }
}
