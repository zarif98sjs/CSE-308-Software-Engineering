package component.framework;

public class Laravel implements Framework{
    public String toString() {
        return "Laravel";
    }
}
