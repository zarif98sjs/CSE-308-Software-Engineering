package component.framework;

public class Spring implements Framework{
    public String toString() {
        return "Spring";
    }
}
