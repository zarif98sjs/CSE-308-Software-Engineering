package component.framework;

public class Django implements Framework{
    public String toString() {
        return "Django";
    }
}
