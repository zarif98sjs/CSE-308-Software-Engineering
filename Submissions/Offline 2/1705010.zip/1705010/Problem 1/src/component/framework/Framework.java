package component.framework;

public interface Framework {
    public String toString();
}
