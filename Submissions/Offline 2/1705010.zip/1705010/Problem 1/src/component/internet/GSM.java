package component.internet;

public class GSM implements Internet{
    public String toString() {
        return "GSM";
    }
}
