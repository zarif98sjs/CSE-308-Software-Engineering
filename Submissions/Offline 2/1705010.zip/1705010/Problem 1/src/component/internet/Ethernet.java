package component.internet;

public class Ethernet implements Internet{
    public String toString() {
        return "Ethernet";
    }
}
