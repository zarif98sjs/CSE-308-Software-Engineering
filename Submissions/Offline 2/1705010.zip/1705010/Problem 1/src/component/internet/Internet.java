package component.internet;

public interface Internet {
    public String toString();
}
