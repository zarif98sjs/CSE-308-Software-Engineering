package component.internet;

public class WiFi implements Internet{
    public String toString() {
        return "WiFi";
    }
}
