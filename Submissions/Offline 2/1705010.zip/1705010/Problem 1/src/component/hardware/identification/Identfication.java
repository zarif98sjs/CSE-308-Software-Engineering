package component.hardware.identification;

public interface Identfication {
    public String toString();
}
