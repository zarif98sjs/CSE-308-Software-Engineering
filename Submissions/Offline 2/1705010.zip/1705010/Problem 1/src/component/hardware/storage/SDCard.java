package component.hardware.storage;

public class SDCard implements Storage{
    public String toString() {
        return "SDCard";
    }
}
