package component.hardware.display;

public class LCD implements Display{
    public String toString() {
        return "LCD";
    }
}
