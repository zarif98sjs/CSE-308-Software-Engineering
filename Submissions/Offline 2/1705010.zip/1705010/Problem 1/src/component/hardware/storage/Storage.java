package component.hardware.storage;

public interface Storage {
    public String toString();
}
