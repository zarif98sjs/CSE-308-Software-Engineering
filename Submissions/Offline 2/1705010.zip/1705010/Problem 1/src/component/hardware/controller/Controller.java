package component.hardware.controller;

public interface Controller {
    public String toString();
}
