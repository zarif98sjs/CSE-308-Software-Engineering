package component.hardware.display;

public class TouchScreen implements Display{
    public String toString() {
        return "TouchScreen";
    }
}
