package component.hardware.identification;

public class NFC implements Identfication{
    public String toString() {
        return "RFID";
    }
}
