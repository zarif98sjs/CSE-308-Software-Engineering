package component.hardware.controller;

public class AddOnController implements Controller{
    public String toString() {
        return "AddOnController";
    }
}
