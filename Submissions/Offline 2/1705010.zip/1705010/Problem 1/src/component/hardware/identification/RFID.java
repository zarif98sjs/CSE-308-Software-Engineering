package component.hardware.identification;

public class RFID implements Identfication{
    public String toString() {
        return "RFID";
    }
}
