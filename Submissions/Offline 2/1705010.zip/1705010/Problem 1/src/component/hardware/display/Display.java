package component.hardware.display;

public interface Display {
    public String toString();
}
