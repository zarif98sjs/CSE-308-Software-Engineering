package component.hardware.display;

public class LED implements Display{
    public String toString() {
        return "LED";
    }
}
