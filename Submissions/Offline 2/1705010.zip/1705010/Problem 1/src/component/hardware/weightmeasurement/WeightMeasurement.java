package component.hardware.weightmeasurement;

public interface WeightMeasurement {
    public String toString();
}
