package component.hardware.storage;

public class BuiltInStorage implements Storage{
    public String toString() {
        return "BuiltInStorage";
    }
}
