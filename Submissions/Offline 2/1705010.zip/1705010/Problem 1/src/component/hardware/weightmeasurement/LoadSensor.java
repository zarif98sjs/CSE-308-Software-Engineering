package component.hardware.weightmeasurement;

public class LoadSensor implements WeightMeasurement{
    public String toString() {
        return "LoadSensor";
    }
}
