package component.hardware.weightmeasurement;

public class WeightModule implements WeightMeasurement{
    public String toString() {
        return "WeightModule";
    }
}
