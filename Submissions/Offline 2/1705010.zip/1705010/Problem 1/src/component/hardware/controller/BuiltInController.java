package component.hardware.controller;

public class BuiltInController implements Controller{
    public String toString() {
        return "BuiltInController";
    }
}
