package Appetizer;

import Decorator.Decorator;

public abstract class AppetizerDecorator extends Decorator {

}
