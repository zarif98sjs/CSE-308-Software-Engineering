package Decorator;

import Pizza.Pizza;

public abstract class Decorator extends Pizza {
    public abstract String getDescription();
}