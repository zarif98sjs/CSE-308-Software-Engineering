package Drinks;

import Decorator.Decorator;

public abstract class DrinksDecorator extends Decorator {
}
