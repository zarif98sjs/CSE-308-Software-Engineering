package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class IntegerFile {

    File file;

    IntegerFile (File file)
    {
        this.file = file;
    }
}
